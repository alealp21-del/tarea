# README.md

# 🌐 Pseudocode Translator - Traductor Multilenguaje

[![Python 3.8+](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GitHub](https://img.shields.io/badge/GitHub-pseudocode--translator-lightgrey)](https://github.com/usuario/pseudocode-translator)

Un compilador modular y extensible que convierte **pseudocódigo** a **Python**, **C** y **JavaScript**.

## 🎯 Características

- ✅ **Tokenizador robusto** - Análisis léxico completo
- ✅ **Parser recursivo descendente** - Análisis sintáctico correcto
- ✅ **AST (Abstract Syntax Tree)** - Representación intermedia completa
- ✅ **3 Generadores de código** - Python, C, JavaScript
- ✅ **Visualización de AST** - Formato árbol y JSON
- ✅ **CLI completo** - Fácil de usar desde terminal
- ✅ **API programática** - Para integración en aplicaciones
- ✅ **Modular y extensible** - Agregar lenguajes fácilmente
- ✅ **Manejo robusto de errores** - Con información de línea/columna

## 📋 Requisitos

- Python 3.8 o superior
- Sin dependencias externas para el core

## 🚀 Instalación

### Opción 1: Desde GitHub (Desarrollo)

```bash
git clone https://github.com/usuario/pseudocode-translator.git
cd pseudocode-translator
pip install -e .
```

### Opción 2: PyPI (Cuando esté publicado)

```bash
pip install pseudocode-translator
```

## 📖 Uso Rápido

### Desde CLI

```bash
# Traducir a Python
pseudocode-translator input.pseudo -o python

# Traducir a todos los lenguajes
pseudocode-translator input.pseudo -o all

# Visualizar AST
pseudocode-translator input.pseudo -v tree

# Guardar AST en JSON
pseudocode-translator input.pseudo --save-ast
```

### Desde Python

```python
from pseudocode_translator.main import PseudocodeTranslator

translator = PseudocodeTranslator()

with open('input.pseudo') as f:
    source = f.read()

if translator.compile(source):
    python_code = translator.translate_to_python()
    print(python_code)
else:
    print("Errores:", translator.get_errors())
```

## 📝 Sintaxis del Pseudolenguaje

### Variables

```
var x = 10
var arr[5]
var mensaje = "Hola"
```

### Control de Flujo

```
si (x > 0) {
    imprimir(x)
} sino {
    imprimir("Negativo")
}

mientras (x > 0) {
    x = x - 1
}

para i = 0 a 10 {
    imprimir(i)
}
```

### Funciones

```
function sumar(a, b) {
    var resultado = a + b
    retorno resultado
}
```

## 🔄 Ejemplos de Traducción

### Entrada (Pseudocódigo)

```
function fibonacci(n) {
    si (n <= 1) {
        retorno n
    }
    var a = 0
    var b = 1
    para i = 2 a n {
        var temp = a + b
        a = b
        b = temp
    }
    retorno b
}
```

### Salida Python

```python
def fibonacci(n):
    if (n <= 1):
        return n
    a = 0
    b = 1
    for i in range(2, n):
        temp = (a + b)
        a = b
        b = temp
    return b
```

### Salida C

```c
#include <stdio.h>

int fibonacci(int n) {
    if ((n <= 1)) {
        return n;
    }
    int a = 0;
    int b = 1;
    for (int i = 2; i < n; i += 1) {
        int temp = (a + b);
        a = b;
        b = temp;
    }
    return b;
}
```

### Salida JavaScript

```javascript
function fibonacci(n) {
    if ((n <= 1)) {
        return n;
    }
    let a = 0;
    let b = 1;
    for (let i = 2; i < n; i += 1) {
        let temp = (a + b);
        a = b;
        b = temp;
    }
    return b;
}
```

## 📚 Tabla de Equivalencias

| Pseudocódigo | Python | C | JavaScript |
|---|---|---|---|
| `var x = 5` | `x = 5` | `int x = 5;` | `let x = 5;` |
| `si (c) {...}` | `if c: ...` | `if (c) {...}` | `if (c) {...}` |
| `mientras (c)` | `while c:` | `while (c)` | `while (c)` |
| `imprimir(x)` | `print(x)` | `printf()` | `console.log(x)` |
| `y` / `and` | `and` | `&&` | `&&` |

## 🏗️ Arquitectura

```
pseudocode-translator/
├── core/
│   ├── tokenizer.py    (Análisis léxico)
│   ├── parser.py       (Análisis sintáctico)
│   └── ast_nodes.py    (Definición de nodos)
├── generators/
│   ├── python_generator.py
│   ├── c_generator.py
│   └── javascript_generator.py
├── visualizer.py       (AST visualization)
└── main.py             (CLI + API)
```

## 🔧 Desarrollo

### Instalar en modo desarrollo

```bash
pip install -e ".[dev]"
```

### Ejecutar pruebas

```bash
pytest tests/
```

### Formato de código

```bash
black pseudocode_translator/
```

## 📦 Estructura del Proyecto

```
.
├── pseudocode_translator/      # Código fuente
├── tests/                       # Pruebas unitarias
├── examples/                    # Archivos de ejemplo
├── docs/                        # Documentación
├── README.md
├── TECHNICAL.md                 # Documentación técnica detallada
├── requirements.txt
├── setup.py
└── .gitignore
```

## 🌟 Próximas Mejoras

- [ ] Soporte para structs/registros
- [ ] Sistema de tipos mejorado
- [ ] Optimización de código generado
- [ ] Más lenguajes (Java, Go, Rust)
- [ ] IDE web integrado
- [ ] Análisis de complejidad
- [ ] Depurador visual

## 📄 Licencia

Este proyecto está bajo la licencia MIT - ver [LICENSE](LICENSE) para más detalles.

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Por favor:

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📞 Contacto

- **GitHub**: [pseudocode-translator](https://github.com/usuario/pseudocode-translator)
- **Issues**: [Bug Reports & Feature Requests](https://github.com/usuario/pseudocode-translator/issues)

## 🎓 Referencias

- Compilers: Principles, Techniques, and Tools (Aho, Sethi, Ullman)
- Engineering a Compiler (Cooper, Torczon)
- Pattern Language for Parsing (Parsing Expression Grammars)

---

**Hecho con ❤️ para la comunidad de programadores**
