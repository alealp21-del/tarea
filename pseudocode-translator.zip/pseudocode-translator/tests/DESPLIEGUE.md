# DEPLOYMENT.md

# 📦 Guía de Despliegue - Pseudocode Translator

## 1. Despliegue Local

### 1.1 Prerequisitos

- Python 3.8 o superior
- pip (gestor de paquetes de Python)
- Git (opcional, para clonar el repositorio)

### 1.2 Instalación

#### Opción A: Desarrollo (con enlace simbólico)

```bash
# Clonar repositorio
git clone https://github.com/usuario/pseudocode-translator.git
cd pseudocode-translator

# Instalar en modo desarrollo
pip install -e .

# Verificar instalación
pseudocode-translator --help
```

#### Opción B: Producción (instalación normal)

```bash
# Descargar el código
cd pseudocode-translator

# Instalar
pip install .

# Verificar
pseudocode-translator --help
```

### 1.3 Verificación

```bash
# Crear archivo de prueba
cat > test.pseudo << EOF
function sumar(a, b) {
    retorno a + b
}
EOF

# Traducir a Python
pseudocode-translator test.pseudo -o python

# Verificar salida
cat test.py
```

## 2. Despliegue en Docker

### 2.1 Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Copiar código
COPY . .

# Instalar
RUN pip install --no-cache-dir -e .

# Establecer punto de entrada
ENTRYPOINT ["pseudocode-translator"]
CMD ["--help"]
```

### 2.2 Construcción y Ejecución

```bash
# Construir imagen
docker build -t pseudocode-translator:latest .

# Ejecutar con archivo local
docker run -v $(pwd):/data pseudocode-translator:latest /data/input.pseudo -o python

# Ejecutar contenedor interactivo
docker run -it pseudocode-translator:latest bash
```

### 2.3 docker-compose.yml

```yaml
version: '3.8'

services:
  translator:
    build: .
    image: pseudocode-translator:latest
    volumes:
      - ./data:/data
    working_dir: /data
    command: ["pseudocode-translator", "input.pseudo", "-o", "all"]
```

## 3. Despliegue en la Nube

### 3.1 AWS Lambda

```bash
# Crear función ZIP
pip install -t package pseudocode-translator
cd package
zip -r ../function.zip .
cd ..
zip function.zip lambda_handler.py

# Crear Lambda con AWS CLI
aws lambda create-function \
  --function-name pseudocode-translator \
  --runtime python3.11 \
  --role arn:aws:iam::ACCOUNT_ID:role/lambda-role \
  --handler lambda_handler.lambda_handler \
  --zip-file fileb://function.zip
```

### 3.2 Heroku

```bash
# Login en Heroku
heroku login

# Crear aplicación
heroku create pseudocode-translator

# Agregar Procfile
echo "web: python -m pseudocode_translator.main" > Procfile

# Commit y deploy
git add .
git commit -m "Deploy to Heroku"
git push heroku main
```

### 3.3 Google Cloud Run

```bash
# Construir imagen
gcloud builds submit --tag gcr.io/PROJECT_ID/pseudocode-translator

# Desplegar
gcloud run deploy pseudocode-translator \
  --image gcr.io/PROJECT_ID/pseudocode-translator \
  --platform managed \
  --region us-central1
```

## 4. API Web (Opcional)

### 4.1 Flask Web Service

```python
# app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
from pseudocode_translator.main import PseudocodeTranslator

app = Flask(__name__)
CORS(app)

@app.route('/translate', methods=['POST'])
def translate():
    data = request.json
    source = data.get('source')
    target = data.get('target', 'python')
    
    translator = PseudocodeTranslator()
    
    if not translator.compile(source):
        return jsonify({'error': translator.get_errors()}), 400
    
    if target == 'python':
        code = translator.translate_to_python()
    elif target == 'c':
        code = translator.translate_to_c()
    elif target == 'javascript':
        code = translator.translate_to_javascript()
    else:
        return jsonify({'error': 'Invalid target'}), 400
    
    return jsonify({'code': code})

@app.route('/ast', methods=['POST'])
def get_ast():
    data = request.json
    source = data.get('source')
    format = data.get('format', 'json')
    
    translator = PseudocodeTranslator()
    
    if not translator.compile(source):
        return jsonify({'error': translator.get_errors()}), 400
    
    ast = translator.visualize_ast(format)
    return jsonify({'ast': ast})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
```

### 4.2 Uso de la API

```bash
# Traducir a Python
curl -X POST http://localhost:5000/translate \
  -H "Content-Type: application/json" \
  -d '{
    "source": "var x = 5",
    "target": "python"
  }'

# Obtener AST
curl -X POST http://localhost:5000/ast \
  -H "Content-Type: application/json" \
  -d '{
    "source": "var x = 5",
    "format": "json"
  }'
```

## 5. CI/CD (GitHub Actions)

### 5.1 .github/workflows/test.yml

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.8', '3.9', '3.10', '3.11']
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v2
      with:
        python-version: ${{ matrix.python-version }}
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -e ".[dev]"
    
    - name: Run tests
      run: |
        pytest tests/ --cov=pseudocode_translator
    
    - name: Lint
      run: |
        pylint pseudocode_translator/
```

### 5.2 .github/workflows/publish.yml

```yaml
name: Publish to PyPI

on:
  release:
    types: [created]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.11'
    
    - name: Build distribution
      run: |
        pip install setuptools wheel twine
        python setup.py sdist bdist_wheel
    
    - name: Publish to PyPI
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: |
        twine upload dist/*
```

## 6. Monitoreo y Logs

### 6.1 Logging Integrado

```python
# pseudocode_translator/logging_config.py
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('translator.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)
```

### 6.2 Monitoreo en Producción

```bash
# Ver logs en tiempo real
tail -f translator.log

# Filtrar por nivel
grep ERROR translator.log
grep WARNING translator.log
```

## 7. Rendimiento y Escalabilidad

### 7.1 Benchmarking

```python
import time
from pseudocode_translator.main import PseudocodeTranslator

translator = PseudocodeTranslator()

# Código de prueba
source = """
function fibonacci(n) {
    si (n <= 1) {
        retorno n
    }
    var a = 0
    var b = 1
    para i = 2 a n {
        var temp = a + b
        a = b
        b = temp
    }
    retorno b
}
""" * 100  # Repetir 100 veces

start = time.time()
translator.compile(source)
compile_time = time.time() - start

start = time.time()
code = translator.translate_to_python()
translate_time = time.time() - start

print(f"Compile time: {compile_time:.4f}s")
print(f"Translate time: {translate_time:.4f}s")
```

### 7.2 Optimizaciones

- Cache de tokens para código frecuente
- Pool de generadores para solicitudes paralelas
- Compilación JIT del bytecode Python

## 8. Backup y Recuperación

### 8.1 Backup de Datos

```bash
# Backup del código
tar -czf pseudocode-translator-backup.tar.gz pseudocode_translator/

# Backup de configuración
cp setup.py requirements.txt setup.py.bak requirements.txt.bak
```

### 8.2 Plan de Recuperación

1. Verificar integridad del backup
2. Restaurar en ambiente de staging
3. Ejecutar pruebas
4. Promover a producción

## 9. Checklist de Despliegue

- [ ] Verificar Python 3.8+ disponible
- [ ] Instalar todas las dependencias
- [ ] Ejecutar pruebas unitarias
- [ ] Generar documentación
- [ ] Crear archivo de ejemplo
- [ ] Probar CLI
- [ ] Probar API (si aplica)
- [ ] Revisar logs
- [ ] Documentar cambios
- [ ] Crear release notes

## 10. Troubleshooting

### Error: "No module named 'pseudocode_translator'"

```bash
# Solución 1: Verificar instalación
pip show pseudocode-translator

# Solución 2: Reinstalar
pip install -e .

# Solución 3: Verificar PYTHONPATH
echo $PYTHONPATH
```

### Error: "Permission denied"

```bash
# Solución 1: Instalar en venv
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# Solución 2: Usar sudo (no recomendado)
sudo pip install pseudocode-translator
```

### Error: "Python version not compatible"

```bash
# Verificar versión
python --version

# Actualizar Python
# En macOS: brew install python@3.11
# En Ubuntu: sudo apt-get install python3.11
# En Windows: Descargar desde python.org
```

---

**Proyecto listo para despliegue en múltiples ambientes** 🚀
