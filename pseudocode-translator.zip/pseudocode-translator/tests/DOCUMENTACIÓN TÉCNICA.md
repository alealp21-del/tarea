# DOCUMENTACIÓN TÉCNICA - TRADUCTOR MULTILENGUAJE

## 1. Introducción

El **Pseudocode Translator** es un compilador multi-objetivo que convierte pseudocódigo a Python, C y JavaScript. Implementa las fases clásicas de un compilador: análisis léxico, análisis sintáctico, generación de AST y generación de código.

## 2. Arquitectura del Sistema

### 2.1 Fases de Compilación

```
Código Fuente (.pseudo)
         ↓
    TOKENIZADOR (Léxico)
         ↓
    Tokens
         ↓
    PARSER (Sintáctico)
         ↓
    AST (Árbol de Sintaxis Abstracta)
         ↓
    GENERADORES (Semántico + Síntesis)
         ↓
    Código Python/C/JavaScript
```

### 2.2 Componentes Principales

#### A. Core Module (`pseudocode_translator/core/`)
- **tokenizer.py**: Análisis léxico, convierte código fuente en tokens
- **parser.py**: Análisis sintáctico recursivo descendente
- **ast_nodes.py**: Definición de nodos del AST y patrón visitor

#### B. Generators (`pseudocode_translator/generators/`)
- **python_generator.py**: Genera código Python
- **c_generator.py**: Genera código C
- **javascript_generator.py**: Genera código JavaScript

#### C. Utilidades
- **visualizer.py**: Visualiza el AST en formato árbol o JSON
- **main.py**: Interfaz principal y CLI

## 3. Especificación del Pseudolenguaje

### 3.1 Palabras Clave

| Pseudocódigo | Inglés | Función |
|---|---|---|
| `function` | function | Definir función |
| `si` | if | Condicional |
| `sino` | else | Alternativa |
| `mientras` | while | Bucle indefinido |
| `para` | for | Bucle definido |
| `retorno` | return | Retornar valor |
| `var` | var | Declaración de variable |
| `array` | array | Tipo de array |
| `verdadero` | true | Booleano verdadero |
| `falso` | false | Booleano falso |
| `y` | and | Operador lógico AND |
| `o` | or | Operador lógico OR |
| `no` | not | Operador lógico NOT |

### 3.2 Operadores

| Operador | Descripción | Precedencia |
|---|---|---|
| `**` | Potencia | 5 (mayor) |
| `*, /, %` | Multiplicación, División, Módulo | 4 |
| `+, -` | Suma, Resta | 3 |
| `<, <=, >, >=` | Comparación | 2 |
| `==, !=` | Igualdad | 2 |
| `y` / `and` | AND lógico | 1 |
| `o` / `or` | OR lógico | 1 (menor) |

### 3.3 Sintaxis

#### Declaración de Variable
```
var nombre = valor
var array[tamaño]
var x = 10
```

#### Condicional
```
si (condición) {
    sentencias
} sino {
    sentencias
}
```

#### Bucle Mientras
```
mientras (condición) {
    sentencias
}
```

#### Bucle Para
```
para i = inicio a fin {
    sentencias
}

para i = inicio a fin paso 2 {
    sentencias
}
```

#### Función
```
function nombre(param1, param2) {
    var x = param1 + param2
    retorno x
}
```

## 4. Tabla de Equivalencias por Lenguaje

### 4.1 Variables

| Pseudocódigo | Python | C | JavaScript |
|---|---|---|---|
| `var x = 5` | `x = 5` | `int x = 5;` | `let x = 5;` |
| `var arr[10]` | `arr = [None]*10` | `int arr[10];` | `let arr = [];` |

### 4.2 Operadores

| Pseudocódigo | Python | C | JavaScript |
|---|---|---|---|
| `y` | `and` | `&&` | `&&` |
| `o` | `or` | \|\| | \|\| |
| `no` | `not` | `!` | `!` |
| `==` | `==` | `==` | `===` |
| `!=` | `!=` | `!=` | `!==` |

### 4.3 Control de Flujo

| Pseudocódigo | Python | C | JavaScript |
|---|---|---|---|
| `si (c) {...}` | `if c: ...` | `if (c) {...}` | `if (c) {...}` |
| `mientras (c)` | `while c:` | `while (c)` | `while (c)` |
| `para i = 0 a 10` | `for i in range(0,10):` | `for(i=0;i<10;i++)` | `for(i=0;i<10;i++)` |

### 4.4 Funciones Integradas

| Pseudocódigo | Python | C | JavaScript |
|---|---|---|---|
| `imprimir(x)` | `print(x)` | `printf("%d", x)` | `console.log(x)` |
| `longitud(arr)` | `len(arr)` | `strlen(arr)` | `arr.length` |

## 5. Ejemplos de Uso

### 5.1 Ejemplo: Calculadora de Fibonacci

**Código Pseudocódigo (fibonacci.pseudo):**
```
function fibonacci(n) {
    si (n <= 1) {
        retorno n
    }
    
    var anterior = 0
    var actual = 1
    
    para i = 2 a n {
        var siguiente = anterior + actual
        anterior = actual
        actual = siguiente
    }
    
    retorno actual
}
```

### 5.2 Traducción a Python

```python
def fibonacci(n):
    if (n <= 1):
        return n
    
    anterior = 0
    actual = 1
    
    for i in range(2, n):
        siguiente = (anterior + actual)
        anterior = actual
        actual = siguiente
    
    return actual
```

### 5.3 Traducción a C

```c
#include <stdio.h>

int fibonacci(int n) {
    if ((n <= 1)) {
        return n;
    }
    
    int anterior = 0;
    int actual = 1;
    
    for (int i = 2; i < n; i += 1) {
        int siguiente = (anterior + actual);
        anterior = actual;
        actual = siguiente;
    }
    
    return actual;
}
```

### 5.4 Traducción a JavaScript

```javascript
function fibonacci(n) {
    if ((n <= 1)) {
        return n;
    }
    
    let anterior = 0;
    let actual = 1;
    
    for (let i = 2; i < n; i += 1) {
        let siguiente = (anterior + actual);
        anterior = actual;
        actual = siguiente;
    }
    
    return actual;
}
```

## 6. Uso de la Herramienta

### 6.1 Instalación

```bash
# Clonar repositorio
git clone https://github.com/usuario/pseudocode-translator.git
cd pseudocode-translator

# Instalar dependencias
pip install -r requirements.txt
```

### 6.2 Uso desde CLI

```bash
# Traducir a Python
python -m pseudocode_translator.main input.pseudo -o python

# Traducir a C
python -m pseudocode_translator.main input.pseudo -o c

# Traducir a JavaScript
python -m pseudocode_translator.main input.pseudo -o javascript

# Traducir a todos los lenguajes
python -m pseudocode_translator.main input.pseudo -o all

# Visualizar AST
python -m pseudocode_translator.main input.pseudo -v tree

# Exportar AST a JSON
python -m pseudocode_translator.main input.pseudo --save-ast
```

### 6.3 Uso como Librería

```python
from pseudocode_translator.main import PseudocodeTranslator

translator = PseudocodeTranslator()

# Leer código fuente
with open('input.pseudo', 'r') as f:
    source = f.read()

# Compilar
if translator.compile(source):
    # Traducir
    python_code = translator.translate_to_python()
    c_code = translator.translate_to_c()
    js_code = translator.translate_to_javascript()
    
    # Visualizar AST
    ast_tree = translator.visualize_ast('tree')
    ast_json = translator.visualize_ast('json')
else:
    print("Errors:", translator.get_errors())
```

## 7. Estructura del Proyecto

```
pseudocode-translator/
├── pseudocode_translator/
│   ├── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── tokenizer.py
│   │   ├── parser.py
│   │   └── ast_nodes.py
│   ├── generators/
│   │   ├── __init__.py
│   │   ├── python_generator.py
│   │   ├── c_generator.py
│   │   └── javascript_generator.py
│   ├── visualizer.py
│   └── main.py
├── tests/
│   ├── test_tokenizer.py
│   ├── test_parser.py
│   ├── test_generators.py
│   └── test_examples.py
├── examples/
│   ├── fibonacci.pseudo
│   ├── bubble_sort.pseudo
│   └── calculator.pseudo
├── README.md
├── requirements.txt
├── setup.py
└── TECHNICAL_DOCS.md
```

## 8. Extensibilidad

### 8.1 Agregar un Nuevo Generador

1. Crear clase que herede de `ASTVisitor`
2. Implementar todos los métodos `visit_*`
3. Registrar en `main.py`

### 8.2 Agregar Nuevas Palabras Clave

1. Añadir a `TokenType` en `tokenizer.py`
2. Añadir al diccionario `KEYWORDS`
3. Crear nodo AST si es necesario
4. Implementar parsing en `parser.py`
5. Implementar generación en todos los generadores

## 9. Manejo de Errores

El traductor implementa manejo robusto de errores:

- **Errores Léxicos**: Caracteres inesperados
- **Errores Sintácticos**: Estructura de código inválida
- **Errores Semánticos**: Validación de tipos y alcance

Todos los errores incluyen información de línea y columna.

## 10. Notas de Implementación

### 10.1 Patrón Visitor

Se utiliza el patrón visitor para recorrer y procesar el AST, permitiendo:
- Múltiples pasadas sobre el árbol
- Separación entre estructura y algoritmo
- Fácil extensión sin modificar nodos

### 10.2 Parsing Recursivo Descendente

Se implementa un parser RD con:
- Precedencia de operadores correcta
- Asociatividad correcta
- Manejo de ambigüedades

### 10.3 Generación de Código

Cada generador:
- Mantiene nivel de indentación
- Mapea constructs a sintaxis específica
- Emite código formateado correctamente

## 11. Limitaciones Actuales

1. No soporta structs/registros
2. No soporta tipos complejos
3. Manejo limitado de excepciones
4. No optimiza el código generado
5. No valida alcance de variables

## 12. Trabajo Futuro

- [ ] Sistema de tipos más robusto
- [ ] Optimizaciones de código
- [ ] Más lenguajes objetivo (Java, Go, Rust)
- [ ] IDE web integrado
- [ ] Depurador visual
- [ ] Análisis de complejidad
