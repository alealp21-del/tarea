# pseudocode_translator/core/tokenizer.py
"""
Tokenizador para el pseudolenguaje.
Convierte el código fuente en una lista de tokens.
"""

import re
from enum import Enum, auto
from dataclasses import dataclass
from typing import List, Optional


class TokenType(Enum):
    """Tipos de tokens disponibles"""
    # Palabras clave
    FUNCTION = auto()
    IF = auto()
    ELSE = auto()
    WHILE = auto()
    FOR = auto()
    RETURN = auto()
    VAR = auto()
    ARRAY = auto()
    TRUE = auto()
    FALSE = auto()
    AND = auto()
    OR = auto()
    NOT = auto()
    
    # Literales
    NUMBER = auto()
    STRING = auto()
    IDENTIFIER = auto()
    
    # Operadores
    PLUS = auto()
    MINUS = auto()
    MULTIPLY = auto()
    DIVIDE = auto()
    MODULO = auto()
    POWER = auto()
    ASSIGN = auto()
    EQ = auto()
    NEQ = auto()
    LT = auto()
    LTE = auto()
    GT = auto()
    GTE = auto()
    
    # Delimitadores
    LPAREN = auto()
    RPAREN = auto()
    LBRACE = auto()
    RBRACE = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    COMMA = auto()
    SEMICOLON = auto()
    COLON = auto()
    DOT = auto()
    ARROW = auto()
    
    # Especiales
    EOF = auto()
    NEWLINE = auto()
    INDENT = auto()
    DEDENT = auto()
    COMMENT = auto()


@dataclass
class Token:
    """Representa un token individual"""
    type: TokenType
    value: str
    line: int
    column: int
    
    def __repr__(self):
        return f"Token({self.type.name}, {repr(self.value)}, {self.line}:{self.column})"


class Tokenizer:
    """Tokenizador del pseudolenguaje"""
    
    KEYWORDS = {
        'function': TokenType.FUNCTION,
        'si': TokenType.IF,
        'if': TokenType.IF,
        'sino': TokenType.ELSE,
        'else': TokenType.ELSE,
        'mientras': TokenType.WHILE,
        'while': TokenType.WHILE,
        'para': TokenType.FOR,
        'for': TokenType.FOR,
        'retorno': TokenType.RETURN,
        'return': TokenType.RETURN,
        'var': TokenType.VAR,
        'array': TokenType.ARRAY,
        'verdadero': TokenType.TRUE,
        'true': TokenType.TRUE,
        'falso': TokenType.FALSE,
        'false': TokenType.FALSE,
        'y': TokenType.AND,
        'and': TokenType.AND,
        'o': TokenType.OR,
        'or': TokenType.OR,
        'no': TokenType.NOT,
        'not': TokenType.NOT,
    }
    
    def __init__(self, source: str):
        self.source = source
        self.position = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
        self.indent_stack = [0]
        
    def error(self, message: str):
        """Lanza un error de tokenización"""
        raise SyntaxError(f"Token error at line {self.line}, column {self.column}: {message}")
    
    def current_char(self) -> Optional[str]:
        """Retorna el carácter actual"""
        if self.position >= len(self.source):
            return None
        return self.source[self.position]
    
    def peek_char(self, offset=1) -> Optional[str]:
        """Retorna el carácter en la posición +offset"""
        pos = self.position + offset
        if pos >= len(self.source):
            return None
        return self.source[pos]
    
    def advance(self):
        """Avanza una posición"""
        if self.position < len(self.source):
            if self.source[self.position] == '\n':
                self.line += 1
                self.column = 1
            else:
                self.column += 1
            self.position += 1
    
    def skip_whitespace(self):
        """Salta espacios en blanco (excepto saltos de línea)"""
        while self.current_char() in (' ', '\t'):
            self.advance()
    
    def skip_comment(self):
        """Salta comentarios"""
        if self.current_char() == '#':
            while self.current_char() and self.current_char() != '\n':
                self.advance()
    
    def read_string(self) -> str:
        """Lee un literal de cadena"""
        quote = self.current_char()
        self.advance()  # Skip opening quote
        value = ""
        
        while self.current_char() and self.current_char() != quote:
            if self.current_char() == '\\':
                self.advance()
                escape_char = self.current_char()
                if escape_char == 'n':
                    value += '\n'
                elif escape_char == 't':
                    value += '\t'
                elif escape_char == '\\':
                    value += '\\'
                elif escape_char == quote:
                    value += quote
                else:
                    value += escape_char
                self.advance()
            else:
                value += self.current_char()
                self.advance()
        
        if not self.current_char():
            self.error("Unterminated string")
        
        self.advance()  # Skip closing quote
        return value
    
    def read_number(self) -> str:
        """Lee un número"""
        value = ""
        has_dot = False
        
        while self.current_char() and (self.current_char().isdigit() or self.current_char() == '.'):
            if self.current_char() == '.':
                if has_dot:
                    break
                has_dot = True
            value += self.current_char()
            self.advance()
        
        return value
    
    def read_identifier(self) -> str:
        """Lee un identificador o palabra clave"""
        value = ""
        while self.current_char() and (self.current_char().isalnum() or self.current_char() in ('_', '-')):
            value += self.current_char()
            self.advance()
        return value
    
    def add_token(self, token_type: TokenType, value: str = ""):
        """Añade un token a la lista"""
        self.tokens.append(Token(token_type, value, self.line, self.column - len(value)))
    
    def tokenize(self) -> List[Token]:
        """Tokeniza el código fuente"""
        while self.position < len(self.source):
            self.skip_whitespace()
            
            if not self.current_char():
                break
            
            # Comentarios
            if self.current_char() == '#':
                self.skip_comment()
                continue
            
            # Saltos de línea
            if self.current_char() == '\n':
                self.advance()
                if self.position < len(self.source) and self.current_char() not in ('\n', '#'):
                    self.tokens.append(Token(TokenType.NEWLINE, '\n', self.line, self.column))
                continue
            
            # Cadenas
            if self.current_char() in ('"', "'"):
                value = self.read_string()
                self.tokens.append(Token(TokenType.STRING, value, self.line, self.column))
                continue
            
            # Números
            if self.current_char().isdigit():
                value = self.read_number()
                self.tokens.append(Token(TokenType.NUMBER, value, self.line, self.column))
                continue
            
            # Identificadores y palabras clave
            if self.current_char().isalpha() or self.current_char() == '_':
                value = self.read_identifier()
                token_type = self.KEYWORDS.get(value.lower(), TokenType.IDENTIFIER)
                self.tokens.append(Token(token_type, value, self.line, self.column))
                continue
            
            # Operadores y delimitadores
            char = self.current_char()
            
            if char == '+':
                self.advance()
                self.add_token(TokenType.PLUS, '+')
            elif char == '-':
                self.advance()
                if self.current_char() == '>':
                    self.advance()
                    self.add_token(TokenType.ARROW, '->')
                else:
                    self.add_token(TokenType.MINUS, '-')
            elif char == '*':
                self.advance()
                if self.current_char() == '*':
                    self.advance()
                    self.add_token(TokenType.POWER, '**')
                else:
                    self.add_token(TokenType.MULTIPLY, '*')
            elif char == '/':
                self.advance()
                self.add_token(TokenType.DIVIDE, '/')
            elif char == '%':
                self.advance()
                self.add_token(TokenType.MODULO, '%')
            elif char == '=':
                self.advance()
                if self.current_char() == '=':
                    self.advance()
                    self.add_token(TokenType.EQ, '==')
                else:
                    self.add_token(TokenType.ASSIGN, '=')
            elif char == '!':
                self.advance()
                if self.current_char() == '=':
                    self.advance()
                    self.add_token(TokenType.NEQ, '!=')
                else:
                    self.error(f"Unexpected character: {char}")
            elif char == '<':
                self.advance()
                if self.current_char() == '=':
                    self.advance()
                    self.add_token(TokenType.LTE, '<=')
                else:
                    self.add_token(TokenType.LT, '<')
            elif char == '>':
                self.advance()
                if self.current_char() == '=':
                    self.advance()
                    self.add_token(TokenType.GTE, '>=')
                else:
                    self.add_token(TokenType.GT, '>')
            elif char == '(':
                self.advance()
                self.add_token(TokenType.LPAREN, '(')
            elif char == ')':
                self.advance()
                self.add_token(TokenType.RPAREN, ')')
            elif char == '{':
                self.advance()
                self.add_token(TokenType.LBRACE, '{')
            elif char == '}':
                self.advance()
                self.add_token(TokenType.RBRACE, '}')
            elif char == '[':
                self.advance()
                self.add_token(TokenType.LBRACKET, '[')
            elif char == ']':
                self.advance()
                self.add_token(TokenType.RBRACKET, ']')
            elif char == ',':
                self.advance()
                self.add_token(TokenType.COMMA, ',')
            elif char == ';':
                self.advance()
                self.add_token(TokenType.SEMICOLON, ';')
            elif char == ':':
                self.advance()
                self.add_token(TokenType.COLON, ':')
            elif char == '.':
                self.advance()
                self.add_token(TokenType.DOT, '.')
            else:
                self.error(f"Unexpected character: {char}")
        
        self.tokens.append(Token(TokenType.EOF, '', self.line, self.column))
        return self.tokens
