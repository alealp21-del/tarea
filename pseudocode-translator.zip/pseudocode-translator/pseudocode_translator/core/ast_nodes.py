# pseudocode_translator/core/ast_nodes.py
"""
Definición de nodos del Árbol de Sintaxis Abstracta (AST)
"""

from dataclasses import dataclass
from typing import List, Optional, Any
from abc import ABC, abstractmethod


class ASTNode(ABC):
    """Clase base para todos los nodos del AST"""
    
    @abstractmethod
    def accept(self, visitor):
        """Patrón visitor para traversal del AST"""
        pass


# Expresiones

@dataclass
class NumberLiteral(ASTNode):
    """Literal numérico: 42, 3.14"""
    value: float
    
    def accept(self, visitor):
        return visitor.visit_number(self)


@dataclass
class StringLiteral(ASTNode):
    """Literal de cadena: "texto" """
    value: str
    
    def accept(self, visitor):
        return visitor.visit_string(self)


@dataclass
class BooleanLiteral(ASTNode):
    """Literal booleano: verdadero, falso"""
    value: bool
    
    def accept(self, visitor):
        return visitor.visit_boolean(self)


@dataclass
class Identifier(ASTNode):
    """Identificador: nombre_variable"""
    name: str
    
    def accept(self, visitor):
        return visitor.visit_identifier(self)


@dataclass
class ArrayLiteral(ASTNode):
    """Literal de array: [1, 2, 3]"""
    elements: List[ASTNode]
    
    def accept(self, visitor):
        return visitor.visit_array_literal(self)


@dataclass
class BinaryOp(ASTNode):
    """Operación binaria: a + b, a < b"""
    left: ASTNode
    operator: str
    right: ASTNode
    
    def accept(self, visitor):
        return visitor.visit_binary_op(self)


@dataclass
class UnaryOp(ASTNode):
    """Operación unaria: -a, no a"""
    operator: str
    operand: ASTNode
    
    def accept(self, visitor):
        return visitor.visit_unary_op(self)


@dataclass
class FunctionCall(ASTNode):
    """Llamada a función: función(arg1, arg2)"""
    name: str
    arguments: List[ASTNode]
    
    def accept(self, visitor):
        return visitor.visit_function_call(self)


@dataclass
class ArrayAccess(ASTNode):
    """Acceso a array: arr[índice]"""
    array: ASTNode
    index: ASTNode
    
    def accept(self, visitor):
        return visitor.visit_array_access(self)


@dataclass
class PropertyAccess(ASTNode):
    """Acceso a propiedad: obj.propiedad"""
    object: ASTNode
    property: str
    
    def accept(self, visitor):
        return visitor.visit_property_access(self)


# Declaraciones

@dataclass
class VariableDeclaration(ASTNode):
    """Declaración de variable: var x = 5"""
    name: str
    value: Optional[ASTNode]
    is_array: bool = False
    array_size: Optional[ASTNode] = None
    
    def accept(self, visitor):
        return visitor.visit_variable_declaration(self)


@dataclass
class Assignment(ASTNode):
    """Asignación: x = valor"""
    target: ASTNode
    value: ASTNode
    
    def accept(self, visitor):
        return visitor.visit_assignment(self)


@dataclass
class IfStatement(ASTNode):
    """Sentencia condicional: si condition"""
    condition: ASTNode
    then_body: List[ASTNode]
    else_body: Optional[List[ASTNode]] = None
    
    def accept(self, visitor):
        return visitor.visit_if_statement(self)


@dataclass
class WhileStatement(ASTNode):
    """Bucle mientras: mientras condition"""
    condition: ASTNode
    body: List[ASTNode]
    
    def accept(self, visitor):
        return visitor.visit_while_statement(self)


@dataclass
class ForStatement(ASTNode):
    """Bucle para: para i = 0 a 10"""
    variable: str
    start: ASTNode
    end: ASTNode
    step: Optional[ASTNode]
    body: List[ASTNode]
    
    def accept(self, visitor):
        return visitor.visit_for_statement(self)


@dataclass
class ReturnStatement(ASTNode):
    """Sentencia de retorno: retorno valor"""
    value: Optional[ASTNode] = None
    
    def accept(self, visitor):
        return visitor.visit_return_statement(self)


@dataclass
class FunctionDefinition(ASTNode):
    """Definición de función"""
    name: str
    parameters: List[str]
    body: List[ASTNode]
    
    def accept(self, visitor):
        return visitor.visit_function_definition(self)


@dataclass
class Program(ASTNode):
    """Nodo raíz del programa"""
    statements: List[ASTNode]
    
    def accept(self, visitor):
        return visitor.visit_program(self)


# Visitor base para patrón visitor

class ASTVisitor(ABC):
    """Clase base para visitantes del AST"""
    
    @abstractmethod
    def visit_number(self, node: NumberLiteral): pass
    
    @abstractmethod
    def visit_string(self, node: StringLiteral): pass
    
    @abstractmethod
    def visit_boolean(self, node: BooleanLiteral): pass
    
    @abstractmethod
    def visit_identifier(self, node: Identifier): pass
    
    @abstractmethod
    def visit_array_literal(self, node: ArrayLiteral): pass
    
    @abstractmethod
    def visit_binary_op(self, node: BinaryOp): pass
    
    @abstractmethod
    def visit_unary_op(self, node: UnaryOp): pass
    
    @abstractmethod
    def visit_function_call(self, node: FunctionCall): pass
    
    @abstractmethod
    def visit_array_access(self, node: ArrayAccess): pass
    
    @abstractmethod
    def visit_property_access(self, node: PropertyAccess): pass
    
    @abstractmethod
    def visit_variable_declaration(self, node: VariableDeclaration): pass
    
    @abstractmethod
    def visit_assignment(self, node: Assignment): pass
    
    @abstractmethod
    def visit_if_statement(self, node: IfStatement): pass
    
    @abstractmethod
    def visit_while_statement(self, node: WhileStatement): pass
    
    @abstractmethod
    def visit_for_statement(self, node: ForStatement): pass
    
    @abstractmethod
    def visit_return_statement(self, node: ReturnStatement): pass
    
    @abstractmethod
    def visit_function_definition(self, node: FunctionDefinition): pass
    
    @abstractmethod
    def visit_program(self, node: Program): pass
