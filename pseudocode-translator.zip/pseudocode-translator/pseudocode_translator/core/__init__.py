# pseudocode_translator/__init__.py
"""
Pseudocode Translator - Compilador multilenguaje
"""

__version__ = "1.0.0"
__author__ = "Pseudocode Translator Team"

from pseudocode_translator.main import PseudocodeTranslator
from pseudocode_translator.core.parser import parse
from pseudocode_translator.visualizer import ASTVisualizer

__all__ = [
    'PseudocodeTranslator',
    'parse',
    'ASTVisualizer',
]
