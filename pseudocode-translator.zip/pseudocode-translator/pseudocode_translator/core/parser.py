# pseudocode_translator/core/parser.py
"""
Parser para el pseudolenguaje.
Construye el AST a partir de los tokens.
"""

from typing import List, Optional
from pseudocode_translator.core.tokenizer import Token, TokenType, Tokenizer
from pseudocode_translator.core.ast_nodes import *


class Parser:
    """Parser recursivo descendente para el pseudolenguaje"""
    
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.position = 0
        
    def error(self, message: str):
        """Lanza un error de parsing"""
        token = self.current_token()
        raise SyntaxError(f"Parse error at line {token.line}, column {token.column}: {message}")
    
    def current_token(self) -> Token:
        """Retorna el token actual"""
        if self.position >= len(self.tokens):
            return self.tokens[-1]  # EOF
        return self.tokens[self.position]
    
    def peek_token(self, offset=1) -> Token:
        """Retorna el token en posición +offset"""
        pos = self.position + offset
        if pos >= len(self.tokens):
            return self.tokens[-1]  # EOF
        return self.tokens[pos]
    
    def advance(self):
        """Avanza a la siguiente token"""
        if self.position < len(self.tokens) - 1:
            self.position += 1
    
    def consume(self, token_type: TokenType) -> Token:
        """Consume un token del tipo especificado o error"""
        token = self.current_token()
        if token.type != token_type:
            self.error(f"Expected {token_type.name}, got {token.type.name}")
        self.advance()
        return token
    
    def skip_newlines(self):
        """Salta tokens NEWLINE"""
        while self.current_token().type == TokenType.NEWLINE:
            self.advance()
    
    def parse(self) -> Program:
        """Inicia el parsing"""
        statements = []
        self.skip_newlines()
        
        while self.current_token().type != TokenType.EOF:
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
            self.skip_newlines()
        
        return Program(statements)
    
    def parse_statement(self) -> Optional[ASTNode]:
        """Parsea una sentencia"""
        token = self.current_token()
        
        if token.type == TokenType.FUNCTION:
            return self.parse_function_definition()
        elif token.type == TokenType.VAR:
            return self.parse_variable_declaration()
        elif token.type == TokenType.IF:
            return self.parse_if_statement()
        elif token.type == TokenType.WHILE:
            return self.parse_while_statement()
        elif token.type == TokenType.FOR:
            return self.parse_for_statement()
        elif token.type == TokenType.RETURN:
            return self.parse_return_statement()
        elif token.type == TokenType.LBRACE:
            return self.parse_block()
        else:
            # Intenta parsear como expresión/asignación
            return self.parse_expression_statement()
    
    def parse_function_definition(self) -> FunctionDefinition:
        """Parsea: function nombre(param1, param2) { cuerpo }"""
        self.consume(TokenType.FUNCTION)
        
        name_token = self.consume(TokenType.IDENTIFIER)
        name = name_token.value
        
        self.consume(TokenType.LPAREN)
        
        parameters = []
        if self.current_token().type != TokenType.RPAREN:
            parameters.append(self.consume(TokenType.IDENTIFIER).value)
            while self.current_token().type == TokenType.COMMA:
                self.advance()
                parameters.append(self.consume(TokenType.IDENTIFIER).value)
        
        self.consume(TokenType.RPAREN)
        self.skip_newlines()
        
        body = self.parse_block()
        if isinstance(body, Program):
            body = body.statements
        else:
            body = [body]
        
        return FunctionDefinition(name, parameters, body)
    
    def parse_variable_declaration(self) -> VariableDeclaration:
        """Parsea: var nombre [= valor]"""
        self.consume(TokenType.VAR)
        
        name_token = self.consume(TokenType.IDENTIFIER)
        name = name_token.value
        
        is_array = False
        array_size = None
        
        if self.current_token().type == TokenType.LBRACKET:
            is_array = True
            self.advance()
            if self.current_token().type != TokenType.RBRACKET:
                array_size = self.parse_expression()
            self.consume(TokenType.RBRACKET)
        
        value = None
        if self.current_token().type == TokenType.ASSIGN:
            self.advance()
            value = self.parse_expression()
        
        return VariableDeclaration(name, value, is_array, array_size)
    
    def parse_if_statement(self) -> IfStatement:
        """Parsea: si condicion { cuerpo } [sino { cuerpo }]"""
        self.consume(TokenType.IF)
        
        condition = self.parse_expression()
        self.skip_newlines()
        
        then_body = self.parse_block_or_statement()
        self.skip_newlines()
        
        else_body = None
        if self.current_token().type == TokenType.ELSE:
            self.advance()
            self.skip_newlines()
            else_body = self.parse_block_or_statement()
        
        return IfStatement(condition, then_body, else_body)
    
    def parse_while_statement(self) -> WhileStatement:
        """Parsea: mientras condicion { cuerpo }"""
        self.consume(TokenType.WHILE)
        
        condition = self.parse_expression()
        self.skip_newlines()
        
        body = self.parse_block_or_statement()
        
        return WhileStatement(condition, body)
    
    def parse_for_statement(self) -> ForStatement:
        """Parsea: para i = inicio a fin { cuerpo }"""
        self.consume(TokenType.FOR)
        
        var_token = self.consume(TokenType.IDENTIFIER)
        variable = var_token.value
        
        self.consume(TokenType.ASSIGN)
        start = self.parse_expression()
        
        # Busca 'a', 'to', o similar
        if self.current_token().type not in (TokenType.IDENTIFIER,):
            self.error("Expected 'to' or 'a' in for loop")
        
        self.advance()  # consume 'a' or 'to'
        
        end = self.parse_expression()
        
        step = None
        if self.current_token().value == 'paso' or self.current_token().value == 'step':
            self.advance()
            step = self.parse_expression()
        
        self.skip_newlines()
        body = self.parse_block_or_statement()
        
        return ForStatement(variable, start, end, step, body)
    
    def parse_return_statement(self) -> ReturnStatement:
        """Parsea: retorno [valor]"""
        self.consume(TokenType.RETURN)
        
        value = None
        if self.current_token().type not in (TokenType.NEWLINE, TokenType.RBRACE, TokenType.EOF, TokenType.SEMICOLON):
            value = self.parse_expression()
        
        return ReturnStatement(value)
    
    def parse_block(self) -> Program:
        """Parsea: { sentencias }"""
        self.consume(TokenType.LBRACE)
        self.skip_newlines()
        
        statements = []
        while self.current_token().type != TokenType.RBRACE:
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
            self.skip_newlines()
        
        self.consume(TokenType.RBRACE)
        
        return Program(statements)
    
    def parse_block_or_statement(self) -> List[ASTNode]:
        """Parsea bloque o sentencia única"""
        if self.current_token().type == TokenType.LBRACE:
            block = self.parse_block()
            return block.statements
        else:
            stmt = self.parse_statement()
            return [stmt] if stmt else []
    
    def parse_expression_statement(self) -> Optional[ASTNode]:
        """Parsea una expresión como sentencia"""
        expr = self.parse_expression()
        
        if expr and self.current_token().type == TokenType.ASSIGN:
            self.advance()
            value = self.parse_expression()
            return Assignment(expr, value)
        
        return expr
    
    def parse_expression(self) -> Optional[ASTNode]:
        """Parsea una expresión"""
        return self.parse_or_expression()
    
    def parse_or_expression(self) -> Optional[ASTNode]:
        """Parsea: expr o expr"""
        left = self.parse_and_expression()
        
        while self.current_token().type in (TokenType.OR,):
            op = self.current_token().value
            self.advance()
            right = self.parse_and_expression()
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_and_expression(self) -> Optional[ASTNode]:
        """Parsea: expr y expr"""
        left = self.parse_comparison()
        
        while self.current_token().type in (TokenType.AND,):
            op = self.current_token().value
            self.advance()
            right = self.parse_comparison()
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_comparison(self) -> Optional[ASTNode]:
        """Parsea: a < b, a == b, etc"""
        left = self.parse_additive()
        
        while self.current_token().type in (TokenType.LT, TokenType.LTE, 
                                           TokenType.GT, TokenType.GTE,
                                           TokenType.EQ, TokenType.NEQ):
            op = self.current_token().value
            self.advance()
            right = self.parse_additive()
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_additive(self) -> Optional[ASTNode]:
        """Parsea: a + b, a - b"""
        left = self.parse_multiplicative()
        
        while self.current_token().type in (TokenType.PLUS, TokenType.MINUS):
            op = self.current_token().value
            self.advance()
            right = self.parse_multiplicative()
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_multiplicative(self) -> Optional[ASTNode]:
        """Parsea: a * b, a / b, a % b"""
        left = self.parse_power()
        
        while self.current_token().type in (TokenType.MULTIPLY, TokenType.DIVIDE, TokenType.MODULO):
            op = self.current_token().value
            self.advance()
            right = self.parse_power()
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_power(self) -> Optional[ASTNode]:
        """Parsea: a ** b"""
        left = self.parse_unary()
        
        if self.current_token().type == TokenType.POWER:
            op = self.current_token().value
            self.advance()
            right = self.parse_power()  # Right-associative
            left = BinaryOp(left, op, right)
        
        return left
    
    def parse_unary(self) -> Optional[ASTNode]:
        """Parsea: -expr, no expr"""
        if self.current_token().type in (TokenType.MINUS, TokenType.NOT):
            op = self.current_token().value
            self.advance()
            operand = self.parse_unary()
            return UnaryOp(op, operand)
        
        return self.parse_postfix()
    
    def parse_postfix(self) -> Optional[ASTNode]:
        """Parsea: expr[idx], expr.prop, expr()"""
        expr = self.parse_primary()
        
        while True:
            if self.current_token().type == TokenType.LBRACKET:
                self.advance()
                index = self.parse_expression()
                self.consume(TokenType.RBRACKET)
                expr = ArrayAccess(expr, index)
            elif self.current_token().type == TokenType.DOT:
                self.advance()
                prop = self.consume(TokenType.IDENTIFIER).value
                expr = PropertyAccess(expr, prop)
            elif self.current_token().type == TokenType.LPAREN and isinstance(expr, Identifier):
                self.advance()
                arguments = []
                if self.current_token().type != TokenType.RPAREN:
                    arguments.append(self.parse_expression())
                    while self.current_token().type == TokenType.COMMA:
                        self.advance()
                        arguments.append(self.parse_expression())
                self.consume(TokenType.RPAREN)
                expr = FunctionCall(expr.name, arguments)
            else:
                break
        
        return expr
    
    def parse_primary(self) -> ASTNode:
        """Parsea: literal, identificador, (expr)"""
        token = self.current_token()
        
        if token.type == TokenType.NUMBER:
            self.advance()
            return NumberLiteral(float(token.value))
        
        elif token.type == TokenType.STRING:
            self.advance()
            return StringLiteral(token.value)
        
        elif token.type == TokenType.TRUE:
            self.advance()
            return BooleanLiteral(True)
        
        elif token.type == TokenType.FALSE:
            self.advance()
            return BooleanLiteral(False)
        
        elif token.type == TokenType.IDENTIFIER:
            self.advance()
            return Identifier(token.value)
        
        elif token.type == TokenType.LBRACKET:
            self.advance()
            elements = []
            if self.current_token().type != TokenType.RBRACKET:
                elements.append(self.parse_expression())
                while self.current_token().type == TokenType.COMMA:
                    self.advance()
                    elements.append(self.parse_expression())
            self.consume(TokenType.RBRACKET)
            return ArrayLiteral(elements)
        
        elif token.type == TokenType.LPAREN:
            self.advance()
            expr = self.parse_expression()
            self.consume(TokenType.RPAREN)
            return expr
        
        else:
            self.error(f"Unexpected token: {token.type.name}")


def parse(source: str) -> Program:
    """Función auxiliar: tokeniza y parsea el código fuente"""
    tokenizer = Tokenizer(source)
    tokens = tokenizer.tokenize()
    parser = Parser(tokens)
    return parser.parse()
