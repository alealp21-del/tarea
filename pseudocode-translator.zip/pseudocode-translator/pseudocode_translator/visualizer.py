# pseudocode_translator/visualizer.py
"""
Visualizador de AST (Abstract Syntax Tree)
Genera representaciones gráficas en JSON y formato de árbol
"""

import json
from pseudocode_translator.core.ast_nodes import *
from typing import Dict, Any, List


class ASTVisualizer:
    """Visualiza el AST en diferentes formatos"""
    
    @staticmethod
    def to_dict(node: ASTNode) -> Dict[str, Any]:
        """Convierte el AST a un diccionario (serializable a JSON)"""
        if isinstance(node, Program):
            return {
                "type": "Program",
                "statements": [ASTVisualizer.to_dict(s) for s in node.statements]
            }
        
        elif isinstance(node, FunctionDefinition):
            return {
                "type": "FunctionDefinition",
                "name": node.name,
                "parameters": node.parameters,
                "body": [ASTVisualizer.to_dict(s) for s in node.body]
            }
        
        elif isinstance(node, VariableDeclaration):
            return {
                "type": "VariableDeclaration",
                "name": node.name,
                "is_array": node.is_array,
                "array_size": ASTVisualizer.to_dict(node.array_size) if node.array_size else None,
                "value": ASTVisualizer.to_dict(node.value) if node.value else None
            }
        
        elif isinstance(node, Assignment):
            return {
                "type": "Assignment",
                "target": ASTVisualizer.to_dict(node.target),
                "value": ASTVisualizer.to_dict(node.value)
            }
        
        elif isinstance(node, IfStatement):
            return {
                "type": "IfStatement",
                "condition": ASTVisualizer.to_dict(node.condition),
                "then_body": [ASTVisualizer.to_dict(s) for s in node.then_body],
                "else_body": [ASTVisualizer.to_dict(s) for s in node.else_body] if node.else_body else None
            }
        
        elif isinstance(node, WhileStatement):
            return {
                "type": "WhileStatement",
                "condition": ASTVisualizer.to_dict(node.condition),
                "body": [ASTVisualizer.to_dict(s) for s in node.body]
            }
        
        elif isinstance(node, ForStatement):
            return {
                "type": "ForStatement",
                "variable": node.variable,
                "start": ASTVisualizer.to_dict(node.start),
                "end": ASTVisualizer.to_dict(node.end),
                "step": ASTVisualizer.to_dict(node.step) if node.step else None,
                "body": [ASTVisualizer.to_dict(s) for s in node.body]
            }
        
        elif isinstance(node, ReturnStatement):
            return {
                "type": "ReturnStatement",
                "value": ASTVisualizer.to_dict(node.value) if node.value else None
            }
        
        elif isinstance(node, BinaryOp):
            return {
                "type": "BinaryOp",
                "operator": node.operator,
                "left": ASTVisualizer.to_dict(node.left),
                "right": ASTVisualizer.to_dict(node.right)
            }
        
        elif isinstance(node, UnaryOp):
            return {
                "type": "UnaryOp",
                "operator": node.operator,
                "operand": ASTVisualizer.to_dict(node.operand)
            }
        
        elif isinstance(node, FunctionCall):
            return {
                "type": "FunctionCall",
                "name": node.name,
                "arguments": [ASTVisualizer.to_dict(a) for a in node.arguments]
            }
        
        elif isinstance(node, ArrayAccess):
            return {
                "type": "ArrayAccess",
                "array": ASTVisualizer.to_dict(node.array),
                "index": ASTVisualizer.to_dict(node.index)
            }
        
        elif isinstance(node, PropertyAccess):
            return {
                "type": "PropertyAccess",
                "object": ASTVisualizer.to_dict(node.object),
                "property": node.property
            }
        
        elif isinstance(node, NumberLiteral):
            return {"type": "NumberLiteral", "value": node.value}
        
        elif isinstance(node, StringLiteral):
            return {"type": "StringLiteral", "value": node.value}
        
        elif isinstance(node, BooleanLiteral):
            return {"type": "BooleanLiteral", "value": node.value}
        
        elif isinstance(node, Identifier):
            return {"type": "Identifier", "name": node.name}
        
        elif isinstance(node, ArrayLiteral):
            return {
                "type": "ArrayLiteral",
                "elements": [ASTVisualizer.to_dict(e) for e in node.elements]
            }
        
        return {"type": "Unknown", "node": str(node)}
    
    @staticmethod
    def to_json(node: ASTNode, indent: int = 2) -> str:
        """Convierte el AST a JSON"""
        return json.dumps(ASTVisualizer.to_dict(node), indent=indent, ensure_ascii=False)
    
    @staticmethod
    def to_tree_string(node: ASTNode, prefix: str = "", is_tail: bool = True) -> str:
        """Convierte el AST a una representación en forma de árbol"""
        node_name = node.__class__.__name__
        
        # Información adicional según el tipo de nodo
        info = ""
        if isinstance(node, Identifier):
            info = f": {node.name}"
        elif isinstance(node, NumberLiteral):
            info = f": {node.value}"
        elif isinstance(node, StringLiteral):
            info = f': "{node.value}"'
        elif isinstance(node, BooleanLiteral):
            info = f": {node.value}"
        elif isinstance(node, BinaryOp):
            info = f": {node.operator}"
        elif isinstance(node, UnaryOp):
            info = f": {node.operator}"
        elif isinstance(node, FunctionDefinition):
            info = f": {node.name}"
        elif isinstance(node, FunctionCall):
            info = f": {node.name}"
        elif isinstance(node, VariableDeclaration):
            info = f": {node.name}"
        elif isinstance(node, ForStatement):
            info = f": {node.variable}"
        elif isinstance(node, PropertyAccess):
            info = f": {node.property}"
        
        result = prefix + ("└── " if is_tail else "├── ") + node_name + info + "\n"
        
        # Recolecta todos los hijos
        children = []
        
        if isinstance(node, Program):
            children = node.statements
        elif isinstance(node, FunctionDefinition):
            children = node.body
        elif isinstance(node, VariableDeclaration):
            if node.value:
                children.append(("value", node.value))
            if node.array_size:
                children.append(("array_size", node.array_size))
        elif isinstance(node, Assignment):
            children = [("target", node.target), ("value", node.value)]
        elif isinstance(node, IfStatement):
            children = [("condition", node.condition), ("then", node.then_body)]
            if node.else_body:
                children.append(("else", node.else_body))
        elif isinstance(node, WhileStatement):
            children = [("condition", node.condition), ("body", node.body)]
        elif isinstance(node, ForStatement):
            children = [("start", node.start), ("end", node.end), ("body", node.body)]
            if node.step:
                children.append(("step", node.step))
        elif isinstance(node, ReturnStatement):
            if node.value:
                children = [("value", node.value)]
        elif isinstance(node, BinaryOp):
            children = [("left", node.left), ("right", node.right)]
        elif isinstance(node, UnaryOp):
            children = [("operand", node.operand)]
        elif isinstance(node, FunctionCall):
            children = [(f"arg{i}", arg) for i, arg in enumerate(node.arguments)]
        elif isinstance(node, ArrayAccess):
            children = [("array", node.array), ("index", node.index)]
        elif isinstance(node, PropertyAccess):
            children = [("object", node.object)]
        elif isinstance(node, ArrayLiteral):
            children = [(f"elem{i}", elem) for i, elem in enumerate(node.elements)]
        
        # Procesa los hijos
        for i, child in enumerate(children):
            is_last = (i == len(children) - 1)
            
            if isinstance(child, tuple):
                label, child_node = child
                child_prefix = prefix + ("    " if is_tail else "│   ")
                if isinstance(child_node, list):
                    result += child_prefix + ("└── " if is_last else "├── ") + label + f" ({len(child_node)} items)\n"
                    for j, item in enumerate(child_node):
                        item_prefix = child_prefix + ("    " if is_last else "│   ")
                        result += ASTVisualizer.to_tree_string(item, item_prefix, j == len(child_node) - 1)
                else:
                    child_prefix = prefix + ("    " if is_tail else "│   ")
                    result += ASTVisualizer.to_tree_string(child_node, child_prefix, is_last)
            else:
                if isinstance(child, list):
                    for j, item in enumerate(child):
                        child_prefix = prefix + ("    " if is_tail else "│   ")
                        result += ASTVisualizer.to_tree_string(item, child_prefix, j == len(child) - 1)
                else:
                    child_prefix = prefix + ("    " if is_tail else "│   ")
                    result += ASTVisualizer.to_tree_string(child, child_prefix, is_last)
        
        return result
    
    @staticmethod
    def visualize(node: ASTNode, format: str = "tree") -> str:
        """Visualiza el AST en el formato especificado (tree o json)"""
        if format == "json":
            return ASTVisualizer.to_json(node)
        else:
            return ASTVisualizer.to_tree_string(node)

