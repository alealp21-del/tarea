# pseudocode_translator/generators/javascript_generator.py
"""
Generador de código JavaScript a partir del AST
"""

from pseudocode_translator.core.ast_nodes import *
from typing import List


class JavaScriptGenerator(ASTVisitor):
    """Genera código JavaScript desde el AST"""
    
    def __init__(self):
        self.code_lines: List[str] = []
        self.indent_level = 0
        self.builtin_functions = {'imprimir': 'console.log', 'longitud': 'length'}
    
    def indent(self) -> str:
        return "    " * self.indent_level
    
    def emit(self, line: str = "", semicolon: bool = False):
        if line:
            full_line = self.indent() + line
            if semicolon and not line.endswith('{') and not line.endswith('}'):
                full_line += ';'
            self.code_lines.append(full_line)
        else:
            self.code_lines.append("")
    
    def generate(self, ast: Program) -> str:
        """Genera código JavaScript desde el AST"""
        ast.accept(self)
        return "\n".join(self.code_lines)
    
    def visit_program(self, node: Program):
        for i, stmt in enumerate(node.statements):
            stmt.accept(self)
            if i < len(node.statements) - 1:
                self.emit()
    
    def visit_function_definition(self, node: FunctionDefinition):
        params = ", ".join(node.parameters)
        self.emit(f"function {node.name}({params}) {{")
        
        self.indent_level += 1
        for stmt in node.body:
            stmt.accept(self)
        self.indent_level -= 1
        
        self.emit("}")
        self.emit()
    
    def visit_variable_declaration(self, node: VariableDeclaration):
        if node.value:
            value = self.expr_to_js(node.value)
            self.emit(f"let {node.name} = {value};")
        else:
            self.emit(f"let {node.name};")
    
    def visit_assignment(self, node: Assignment):
        target = self.expr_to_js(node.target)
        value = self.expr_to_js(node.value)
        self.emit(f"{target} = {value};")
    
    def visit_if_statement(self, node: IfStatement):
        condition = self.expr_to_js(node.condition)
        self.emit(f"if ({condition}) {{")
        
        self.indent_level += 1
        for stmt in node.then_body:
            stmt.accept(self)
        self.indent_level -= 1
        
        if node.else_body:
            self.emit("} else {")
            self.indent_level += 1
            for stmt in node.else_body:
                stmt.accept(self)
            self.indent_level -= 1
        
        self.emit("}")
    
    def visit_while_statement(self, node: WhileStatement):
        condition = self.expr_to_js(node.condition)
        self.emit(f"while ({condition}) {{")
        
        self.indent_level += 1
        for stmt in node.body:
            stmt.accept(self)
        self.indent_level -= 1
        
        self.emit("}")
    
    def visit_for_statement(self, node: ForStatement):
        start = self.expr_to_js(node.start)
        end = self.expr_to_js(node.end)
        step = self.expr_to_js(node.step) if node.step else "1"
        
        self.emit(f"for (let {node.variable} = {start}; {node.variable} < {end}; {node.variable} += {step}) {{")
        
        self.indent_level += 1
        for stmt in node.body:
            stmt.accept(self)
        self.indent_level -= 1
        
        self.emit("}")
    
    def visit_return_statement(self, node: ReturnStatement):
        if node.value:
            value = self.expr_to_js(node.value)
            self.emit(f"return {value};")
        else:
            self.emit("return;")
    
    def expr_to_js(self, expr: ASTNode) -> str:
        """Convierte expresión a código JavaScript"""
        if isinstance(expr, NumberLiteral):
            return str(int(expr.value) if expr.value == int(expr.value) else expr.value)
        
        elif isinstance(expr, StringLiteral):
            return f'"{expr.value}"'
        
        elif isinstance(expr, BooleanLiteral):
            return "true" if expr.value else "false"
        
        elif isinstance(expr, Identifier):
            return expr.name
        
        elif isinstance(expr, ArrayLiteral):
            elements = ", ".join(self.expr_to_js(e) for e in expr.elements)
            return f"[{elements}]"
        
        elif isinstance(expr, BinaryOp):
            left = self.expr_to_js(expr.left)
            right = self.expr_to_js(expr.right)
            
            ops = {
                '+': '+', '-': '-', '*': '*', '/': '/', '%': '%', '**': '**',
                '==': '===', '!=': '!==', '<': '<', '<=': '<=', '>': '>', '>=': '>=',
                'y': '&&', 'and': '&&', 'o': '||', 'or': '||'
            }
            op = ops.get(expr.operator, expr.operator)
            return f"({left} {op} {right})"
        
        elif isinstance(expr, UnaryOp):
            operand = self.expr_to_js(expr.operand)
            ops = {'-': '-', 'no': '!', 'not': '!'}
            op = ops.get(expr.operator, expr.operator)
            return f"({op}{operand})"
        
        elif isinstance(expr, FunctionCall):
            args = ", ".join(self.expr_to_js(arg) for arg in expr.arguments)
            
            if expr.name == 'imprimir':
                return f"console.log({args})"
            elif expr.name == 'longitud':
                return f"{args}.length"
            
            return f"{expr.name}({args})"
        
        elif isinstance(expr, ArrayAccess):
            array = self.expr_to_js(expr.array)
            index = self.expr_to_js(expr.index)
            return f"{array}[Math.floor({index})]"
        
        elif isinstance(expr, PropertyAccess):
            obj = self.expr_to_js(expr.object)
            return f"{obj}.{expr.property}"
        
        return str(expr)
    
    def visit_number(self, node: NumberLiteral): pass
    def visit_string(self, node: StringLiteral): pass
    def visit_boolean(self, node: BooleanLiteral): pass
    def visit_identifier(self, node: Identifier): pass
    def visit_array_literal(self, node: ArrayLiteral): pass
    def visit_function_call(self, node: FunctionCall): pass
    def visit_array_access(self, node: ArrayAccess): pass
    def visit_property_access(self, node: PropertyAccess): pass
