# pseudocode_translator/generators/python_generator.py
"""
Generador de código Python a partir del AST
"""

from pseudocode_translator.core.ast_nodes import *
from typing import List


class PythonGenerator(ASTVisitor):
    """Genera código Python desde el AST"""
    
    def __init__(self):
        self.code_lines: List[str] = []
        self.indent_level = 0
        self.builtin_functions = {'imprimir': 'print', 'longitud': 'len', 'rango': 'range'}
    
    def indent(self) -> str:
        """Retorna el nivel de indentación actual"""
        return "    " * self.indent_level
    
    def emit(self, line: str = ""):
        """Emite una línea de código"""
        if line:
            self.code_lines.append(self.indent() + line)
        else:
            self.code_lines.append("")
    
    def generate(self, ast: Program) -> str:
        """Genera código Python desde el AST"""
        ast.accept(self)
        return "\n".join(self.code_lines)
    
    def visit_program(self, node: Program):
        for stmt in node.statements:
            stmt.accept(self)
            self.emit()
    
    def visit_function_definition(self, node: FunctionDefinition):
        params = ", ".join(node.parameters)
        self.emit(f"def {node.name}({params}):")
        self.indent_level += 1
        for stmt in node.body:
            stmt.accept(self)
        self.indent_level -= 1
        self.emit()
    
    def visit_variable_declaration(self, node: VariableDeclaration):
        if node.is_array:
            if node.array_size:
                self.emit(f"{node.name} = [None] * int({self.expr_to_python(node.array_size)})")
            elif node.value:
                self.emit(f"{node.name} = {self.expr_to_python(node.value)}")
            else:
                self.emit(f"{node.name} = []")
        else:
            if node.value:
                self.emit(f"{node.name} = {self.expr_to_python(node.value)}")
            else:
                self.emit(f"{node.name} = None")
    
    def visit_assignment(self, node: Assignment):
        target = self.expr_to_python(node.target)
        value = self.expr_to_python(node.value)
        self.emit(f"{target} = {value}")
    
    def visit_if_statement(self, node: IfStatement):
        condition = self.expr_to_python(node.condition)
        self.emit(f"if {condition}:")
        self.indent_level += 1
        for stmt in node.then_body:
            stmt.accept(self)
        self.indent_level -= 1
        
        if node.else_body:
            self.emit("else:")
            self.indent_level += 1
            for stmt in node.else_body:
                stmt.accept(self)
            self.indent_level -= 1
    
    def visit_while_statement(self, node: WhileStatement):
        condition = self.expr_to_python(node.condition)
        self.emit(f"while {condition}:")
        self.indent_level += 1
        for stmt in node.body:
            stmt.accept(self)
        self.indent_level -= 1
    
    def visit_for_statement(self, node: ForStatement):
        start = self.expr_to_python(node.start)
        end = self.expr_to_python(node.end)
        step = f", {self.expr_to_python(node.step)}" if node.step else ""
        
        self.emit(f"for {node.variable} in range({start}, {end}{step}):")
        self.indent_level += 1
        for stmt in node.body:
            stmt.accept(self)
        self.indent_level -= 1
    
    def visit_return_statement(self, node: ReturnStatement):
        if node.value:
            self.emit(f"return {self.expr_to_python(node.value)}")
        else:
            self.emit("return")
    
    def expr_to_python(self, expr: ASTNode) -> str:
        """Convierte una expresión del AST a código Python"""
        if isinstance(expr, NumberLiteral):
            return str(expr.value)
        
        elif isinstance(expr, StringLiteral):
            return f'"{expr.value}"'
        
        elif isinstance(expr, BooleanLiteral):
            return "True" if expr.value else "False"
        
        elif isinstance(expr, Identifier):
            return expr.name
        
        elif isinstance(expr, ArrayLiteral):
            elements = ", ".join(self.expr_to_python(e) for e in expr.elements)
            return f"[{elements}]"
        
        elif isinstance(expr, BinaryOp):
            left = self.expr_to_python(expr.left)
            right = self.expr_to_python(expr.right)
            
            ops = {
                '+': '+', '-': '-', '*': '*', '/': '/', '%': '%', '**': '**',
                '==': '==', '!=': '!=', '<': '<', '<=': '<=', '>': '>', '>=': '>=',
                'y': 'and', 'and': 'and', 'o': 'or', 'or': 'or'
            }
            op = ops.get(expr.operator, expr.operator)
            return f"({left} {op} {right})"
        
        elif isinstance(expr, UnaryOp):
            operand = self.expr_to_python(expr.operand)
            ops = {'-': '-', 'no': 'not', 'not': 'not'}
            op = ops.get(expr.operator, expr.operator)
            return f"({op} {operand})"
        
        elif isinstance(expr, FunctionCall):
            func_name = self.builtin_functions.get(expr.name, expr.name)
            args = ", ".join(self.expr_to_python(arg) for arg in expr.arguments)
            return f"{func_name}({args})"
        
        elif isinstance(expr, ArrayAccess):
            array = self.expr_to_python(expr.array)
            index = self.expr_to_python(expr.index)
            return f"{array}[int({index})]"
        
        elif isinstance(expr, PropertyAccess):
            obj = self.expr_to_python(expr.object)
            return f"{obj}.{expr.property}"
        
        return str(expr)
    
    def visit_number(self, node: NumberLiteral): pass
    def visit_string(self, node: StringLiteral): pass
    def visit_boolean(self, node: BooleanLiteral): pass
    def visit_identifier(self, node: Identifier): pass
    def visit_array_literal(self, node: ArrayLiteral): pass
    def visit_binary_op(self, node: BinaryOp): pass
    def visit_unary_op(self, node: UnaryOp): pass
    def visit_function_call(self, node: FunctionCall): pass
    def visit_array_access(self, node: ArrayAccess): pass
    def visit_property_access(self, node: PropertyAccess): pass
