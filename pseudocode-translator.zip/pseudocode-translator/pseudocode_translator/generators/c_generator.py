# pseudocode_translator/generators/c_generator.py
"""
Generador de código C a partir del AST
"""

from pseudocode_translator.core.ast_nodes import *
from typing import List, Set


class CGenerator(ASTVisitor):
    """Genera código C desde el AST"""
    
    def __init__(self):
        self.code_lines: List[str] = []
        self.indent_level = 0
        self.includes: Set[str] = set()
        self.variables: dict = {}
        self.builtin_functions = {'imprimir': 'printf', 'longitud': 'strlen'}
    
    def indent(self) -> str:
        return "    " * self.indent_level
    
    def emit(self, line: str = ""):
        if line:
            self.code_lines.append(self.indent() + line)
        else:
            self.code_lines.append("")
    
    def add_include(self, header: str):
        self.includes.add(header)
    
    def generate(self, ast: Program) -> str:
        """Genera código C desde el AST"""
        # Emite includes
        for header in sorted(self.includes):
            self.emit(f"#include <{header}>")
        
        if self.includes:
            self.emit()
        
        # Procesa el AST
        ast.accept(self)
        
        return "\n".join(self.code_lines)
    
    def visit_program(self, node: Program):
        for stmt in node.statements:
            if isinstance(stmt, FunctionDefinition):
                stmt.accept(self)
            else:
                stmt.accept(self)
    
    def visit_function_definition(self, node: FunctionDefinition):
        self.add_include("stdio.h")
        
        # Declaración de función
        params = ", ".join(f"int {p}" for p in node.parameters)
        if not params:
            params = "void"
        
        self.emit(f"int {node.name}({params}) {{")
        self.indent_level += 1
        
        for stmt in node.body:
            stmt.accept(self)
        
        # Retorno por defecto
        self.emit("return 0;")
        
        self.indent_level -= 1
        self.emit("}")
        self.emit()
    
    def visit_variable_declaration(self, node: VariableDeclaration):
        if node.is_array:
            if node.array_size:
                size = self.expr_to_c(node.array_size)
                self.emit(f"int {node.name}[{size}];")
            else:
                self.emit(f"int {node.name}[100];")
        else:
            if node.value:
                value = self.expr_to_c(node.value)
                self.emit(f"int {node.name} = {value};")
            else:
                self.emit(f"int {node.name};")
        
        self.variables[node.name] = 'int'
    
    def visit_assignment(self, node: Assignment):
        target = self.expr_to_c(node.target)
        value = self.expr_to_c(node.value)
        self.emit(f"{target} = {value};")
    
    def visit_if_statement(self, node: IfStatement):
        condition = self.expr_to_c(node.condition)
        self.emit(f"if ({condition}) {{")
        
        self.indent_level += 1
        for stmt in node.then_body:
            stmt.accept(self)
        self.indent_level -= 1
        
        if node.else_body:
            self.emit("} else {")
            self.indent_level += 1
            for stmt in node.else_body:
                stmt.accept(self)
            self.indent_level -= 1
        
        self.emit("}")
    
    def visit_while_statement(self, node: WhileStatement):
        condition = self.expr_to_c(node.condition)
        self.emit(f"while ({condition}) {{")
        
        self.indent_level += 1
        for stmt in node.body:
            stmt.accept(self)
        self.indent_level -= 1
        
        self.emit("}")
    
    def visit_for_statement(self, node: ForStatement):
        start = self.expr_to_c(node.start)
        end = self.expr_to_c(node.end)
        step = self.expr_to_c(node.step) if node.step else "1"
        
        self.emit(f"for (int {node.variable} = {start}; {node.variable} < {end}; {node.variable} += {step}) {{")
        
        self.indent_level += 1
        for stmt in node.body:
            stmt.accept(self)
        self.indent_level -= 1
        
        self.emit("}")
    
    def visit_return_statement(self, node: ReturnStatement):
        if node.value:
            value = self.expr_to_c(node.value)
            self.emit(f"return {value};")
        else:
            self.emit("return 0;")
    
    def expr_to_c(self, expr: ASTNode) -> str:
        """Convierte expresión a código C"""
        if isinstance(expr, NumberLiteral):
            return str(int(expr.value) if expr.value == int(expr.value) else expr.value)
        
        elif isinstance(expr, StringLiteral):
            return f'"{expr.value}"'
        
        elif isinstance(expr, BooleanLiteral):
            return "1" if expr.value else "0"
        
        elif isinstance(expr, Identifier):
            return expr.name
        
        elif isinstance(expr, BinaryOp):
            left = self.expr_to_c(expr.left)
            right = self.expr_to_c(expr.right)
            
            ops = {
                '+': '+', '-': '-', '*': '*', '/': '/', '%': '%', '**': 'pow(',
                '==': '==', '!=': '!=', '<': '<', '<=': '<=', '>': '>', '>=': '>=',
                'y': '&&', 'and': '&&', 'o': '||', 'or': '||'
            }
            
            op = ops.get(expr.operator, expr.operator)
            
            if op == 'pow(':
                self.add_include("math.h")
                return f"pow({left}, {right})"
            
            return f"({left} {op} {right})"
        
        elif isinstance(expr, UnaryOp):
            operand = self.expr_to_c(expr.operand)
            ops = {'-': '-', 'no': '!', 'not': '!'}
            op = ops.get(expr.operator, expr.operator)
            return f"({op}{operand})"
        
        elif isinstance(expr, FunctionCall):
            func_name = self.builtin_functions.get(expr.name, expr.name)
            args = ", ".join(self.expr_to_c(arg) for arg in expr.arguments)
            return f"{func_name}({args})"
        
        elif isinstance(expr, ArrayAccess):
            array = self.expr_to_c(expr.array)
            index = self.expr_to_c(expr.index)
            return f"{array}[(int){index}]"
        
        return str(expr)
    
    def visit_number(self, node: NumberLiteral): pass
    def visit_string(self, node: StringLiteral): pass
    def visit_boolean(self, node: BooleanLiteral): pass
    def visit_identifier(self, node: Identifier): pass
    def visit_array_literal(self, node: ArrayLiteral): pass
    def visit_function_call(self, node: FunctionCall): pass
    def visit_array_access(self, node: ArrayAccess): pass
    def visit_property_access(self, node: PropertyAccess): pass
